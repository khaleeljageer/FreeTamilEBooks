package com.jskhaleel.reader

import android.app.Application
import com.google.android.material.color.DynamicColors
import timber.log.Timber

object EPubReader {
    private var readerConfig: ReaderConfig? = null

    fun init(application: Application) {
        Timber.plant(Timber.DebugTree())
        this.readerConfig = ReaderConfig(application)
    }

    fun getReader(): Reader {
        readerConfig ?: throw IllegalStateException("Readium config not initialized")
        return ReaderImpl(readerConfig!!)
    }
}