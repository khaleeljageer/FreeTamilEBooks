package com.jskhaleel.reader.data

import com.jskhaleel.reader.reader.OpeningError
import com.jskhaleel.reader.reader.ReaderInitData
import org.readium.r2.shared.util.Try

interface ReaderRepository {
    suspend fun open(bookId: Long): Try<Unit, OpeningError>
    fun close(bookId: Long)
    fun getReaderInit(bookId: Long): ReaderInitData
    fun isEmpty(): Boolean
}