package com.jskhaleel.reader.di

import android.content.Context
import androidx.room.Room
import com.jskhaleel.reader.data.db.BooksDao
import com.jskhaleel.reader.data.db.CatalogDao
import com.jskhaleel.reader.data.db.ReaderDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class DatabaseModule {
    @Provides
    @Singleton
    fun provideBookDatabase(@ApplicationContext context: Context): ReaderDatabase {
        return Room.databaseBuilder(
            context,
            ReaderDatabase::class.java,
            APP_DATABASE_NAME,
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    @Singleton
    fun getBooksDao(appDatabase: ReaderDatabase): BooksDao {
        return appDatabase.booksDao()
    }

    @Provides
    @Singleton
    fun getCatalogDao(appDatabase: ReaderDatabase): CatalogDao {
        return appDatabase.catalogDao()
    }

    companion object {
        private const val APP_DATABASE_NAME = "reader_db"
    }
}