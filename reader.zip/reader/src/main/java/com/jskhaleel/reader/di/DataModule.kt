package com.jskhaleel.reader.di

import com.jskhaleel.reader.data.ReaderRepositoryImpl
import com.jskhaleel.reader.data.BookRepository
import com.jskhaleel.reader.data.BookRepositoryImpl
import com.jskhaleel.reader.data.ReaderRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class DataModule {
    @Binds
    @Singleton
    abstract fun getBookRepository(
        bookRepositoryImpl: BookRepositoryImpl,
    ): BookRepository

    @Binds
    @Singleton
    abstract fun getReaderRepository(
        readerRepositoryImpl: ReaderRepositoryImpl,
    ): ReaderRepository
}