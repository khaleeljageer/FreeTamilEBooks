package com.jskhaleel.reader

import android.net.Uri

interface Reader {
    suspend fun openBook(bookId: Long)
    suspend fun deleteBook(bookId: Long)
    suspend fun importPublicationFromStorage(toUri: Uri)
}