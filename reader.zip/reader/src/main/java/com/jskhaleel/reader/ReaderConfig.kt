package com.jskhaleel.reader

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.google.android.material.color.DynamicColors
import com.jskhaleel.reader.data.BookRepository
import com.jskhaleel.reader.data.ReaderRepository
import com.jskhaleel.reader.domain.CoverStorage
import com.jskhaleel.reader.domain.ImportError
import com.jskhaleel.reader.domain.LibraryManager.ImportResult
import com.jskhaleel.reader.domain.PublicationError.Companion.invoke
import com.jskhaleel.reader.domain.PublicationRetriever
import com.jskhaleel.reader.reader.ReaderActivity
import com.jskhaleel.reader.reader.ReaderActivityContract
import com.jskhaleel.reader.utils.extensions.computeStorageDir
import com.jskhaleel.reader.utils.extensions.copyToTempFile
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import org.readium.r2.shared.util.AbsoluteUrl
import org.readium.r2.shared.util.DebugError
import org.readium.r2.shared.util.Try
import org.readium.r2.shared.util.file.FileSystemError
import org.readium.r2.shared.util.format.Format
import org.readium.r2.shared.util.getOrElse
import org.readium.r2.shared.util.toUrl
import timber.log.Timber
import java.io.File
import javax.inject.Singleton

@Singleton
class ReaderConfig(private val application: Application) {
    @EntryPoint
    @InstallIn(SingletonComponent::class)
    interface ReadiumConfigEntryPoint {
        fun provideReadium(): Readium
        fun provideCoroutineScope(): CoroutineScope
        fun getBookRepository(): BookRepository
        fun getReaderRepository(): ReaderRepository
    }

    private val storageDir = application.computeStorageDir()

    private val hiltEntryPoint = EntryPointAccessors.fromApplication(
        application,
        ReadiumConfigEntryPoint::class.java
    )

    private fun getReadium(): Readium {
        return hiltEntryPoint.provideReadium()
    }

    private fun getBookRepository(): BookRepository {
        return hiltEntryPoint.getBookRepository()
    }

    private fun getReaderRepository(): ReaderRepository {
        return hiltEntryPoint.getReaderRepository()
    }

    private fun provideCoroutineScope(): CoroutineScope {
        return hiltEntryPoint.provideCoroutineScope()
    }

    suspend fun importBookFromUri(uri: Uri) {
        val readium = getReadium()
        val downloadsDir = File(application.cacheDir, "downloads")
        val publicationRetriever = PublicationRetriever(
            context = application,
            assetRetriever = readium.assetRetriever,
            bookshelfDir = storageDir,
            tempDir = downloadsDir,
            httpClient = readium.httpClient,
            lcpService = readium.lcpService.getOrNull()
        )
        val result = publicationRetriever.retrieveFromStorage(uri)
        handleImportResult(result)
    }

    private suspend fun handleImportResult(
        retrieverResult: Try<PublicationRetriever.Result, ImportError>
    ): ImportResult {
        return retrieverResult
            .map { addBook(it.publication.toUrl(), it.format, it.coverUrl) }
            .fold(
                onSuccess = { ImportResult.Success },
                onFailure = { ImportResult.Error(it) }
            )
    }

    suspend fun addBook(
        url: AbsoluteUrl,
        format: Format? = null,
        coverUrl: AbsoluteUrl? = null
    ): Try<Unit, ImportError> {
        val readium = getReadium()
        val asset = if (format == null) {
            readium.assetRetriever.retrieve(url)
        } else {
            readium.assetRetriever.retrieve(url, format)
        }.getOrElse {
            return Try.failure(
                ImportError.Publication(
                    com.jskhaleel.reader.domain.PublicationError(
                        it
                    )
                )
            )
        }

        readium.publicationOpener.open(asset, allowUserInteraction = false)
            .onSuccess { publication ->
                val coverStorage = CoverStorage(storageDir, httpClient = readium.httpClient)
                val coverFile = coverStorage.storeCover(publication, coverUrl)
                    .getOrElse {
                        return Try.failure(ImportError.FileSystem(FileSystemError.IO(it)))
                    }

                val id = getBookRepository().insertBook(
                    url,
                    asset.format.mediaType,
                    publication,
                    coverFile
                )
                if (id == -1L) {
                    coverFile.delete()
                    return Try.failure(
                        ImportError.Database(
                            DebugError("Could not insert book into database.")
                        )
                    )
                }
            }
            .onFailure {
                Timber.e("Cannot open publication: $it.")
                return Try.failure(
                    ImportError.Publication(
                        com.jskhaleel.reader.domain.PublicationError(
                            it
                        )
                    )
                )
            }

        return Try.success(Unit)
    }

    suspend fun openBook(bookId: Long) {
        getReaderRepository().open(bookId).fold(
            onSuccess = {
                launchReaderActivity(context = application.applicationContext)
            },
            onFailure = {
                Timber.tag("Khaleel").d("Open Error: $it")
            }
        )
    }

    private fun launchReaderActivity(context: Context) {
        DynamicColors.applyToActivitiesIfAvailable(application)
        val intent = Intent(context, ReaderActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        intent.putExtra("book_id", 1)
        context.startActivity(intent)
    }
}
