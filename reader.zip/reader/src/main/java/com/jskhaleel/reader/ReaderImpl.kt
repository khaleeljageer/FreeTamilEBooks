package com.jskhaleel.reader

import android.net.Uri

class ReaderImpl(private val readerConfig: ReaderConfig) : Reader {
    override suspend fun openBook(bookId: Long) {
        readerConfig.openBook(bookId)
    }

    override suspend fun deleteBook(bookId: Long) {

    }

    override suspend fun importPublicationFromStorage(toUri: Uri) {
        readerConfig.importBookFromUri(toUri)
    }
}